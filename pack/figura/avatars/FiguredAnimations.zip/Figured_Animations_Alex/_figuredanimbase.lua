models.model.Player:primaryTexture("SKIN") --Delete / disable this if you want to use a custom skin that is loaded from a file in the model.bbmodel
models.model.Player.root.Torso.Body.Cape:primaryTexture("CAPE") --Delete / disable this if you want to use a custom cape that is loaded from a file in the model.bbmodel

vanilla_model.PLAYER:visible(false)
vanilla_model.CAPE:visible(false)
