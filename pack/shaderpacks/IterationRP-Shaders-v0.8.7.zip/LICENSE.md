Copyright (C) 2025 Tahnass

All Rights Reserved unless explicit permission.

Independent hosting and redistribution are prohibited, as is using link 
monetization services. Websites or blogs collecting similar projects must 
obtain explicit permission before including this project. 

Private modifications are allowed without permission, but redistributing 
modified versions requires the author's consent. Public redistribution of 
modified versions also needs explicit permission, must include significant 
original work, use the same license, and credit the original project and 
author. Monetization of modified versions is prohibited without permission. 

Using parts of this project's source code in another original project also 
requires explicit permission and proper credit, with monetization prohibited 
unless authorized.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.